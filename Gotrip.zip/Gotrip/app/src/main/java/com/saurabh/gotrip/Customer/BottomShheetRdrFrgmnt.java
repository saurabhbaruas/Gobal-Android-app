package com.saurabh.gotrip.Customer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.saurabh.gotrip.R;

public class BottomShheetRdrFrgmnt extends BottomSheetDialogFragment {

    String mTag;

    public static  BottomSheetDialogFragment newInstance(String tag)
    {
        BottomShheetRdrFrgmnt f = new BottomShheetRdrFrgmnt();
        Bundle args = new Bundle();
        args.putString("Tag",tag);
        f.setArguments(args);
        return f;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mTag = getArguments().getString("TAG");



    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_bottom_shheet_rdr_frgmnt, container, false);
        return  view;
    }
}
