package com.saurabh.gotrip.Customer.Common;

import android.location.Location;

import com.saurabh.gotrip.Customer.Model.Rider;

public class Common {

    public static boolean isDriverFound = false;


    public static final String driver_tbl = "Drivers";
    public static final String user_driver_tbl = "DriversInfo";
    public static final String user_rider_tbl = "RidersInfo";
    public static final String pickup_request_tbl = "PickupRequest";
    public static final String token_tbl = "Tokens";

    //Auto login systm
    public static final String user_field="rider_user"; //diff bcz 1 phone number
    public static final String pwd_field="rider_pwd";
    //upload img
    public static final int    PICK_IMAGE_REQUEST = 9999;

    public static String driverId="";


    //global var for rider updateInfo26
    public  static Rider currentUser = new Rider();
    //fused location
    public static Location mLastLocation;

}
