package com.saurabh.gotrip.Customer;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.arsy.maps_library.MapRipple;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.saurabh.gotrip.R;
import com.saurabh.gotrip.Customer.Common.Common;
import com.saurabh.gotrip.Customer.Helper.CustomInfoWin;
import com.saurabh.gotrip.Customer.Model.Rider;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;
import dmax.dialog.SpotsDialog;
import io.paperdb.Paper;

public class RiderHome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback,
        GoogleMap.OnInfoWindowClickListener, ValueEventListener
{

    // private AppBarConfiguration mAppBarConfiguration;
    SupportMapFragment mapFragment;

    //FusedLocation
    FusedLocationProviderClient fusedLocationProviderClient;
    LocationCallback locationCallback;

    //Location
    private GoogleMap mMap;
    private static  final int MY_PERMISSION_REQUEST_CODE =7000;
    private static final int PLAY_SERVICES_RES_REQUEST = 7001;
    private LocationRequest mLocationReqest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;
    private static int UPDATE_INTERVAL = 5000;
    private static int FASTEST_INTERVAL = 3000;
    private static int DISPLACEMENT = 10;
    DatabaseReference ref;
    GeoFire geoFire;
    Marker mUserMarker,markerDestination;

    //Bottomsheet
    ImageView imgExpandable;
    //BottomSheetRiderFragment mBottomSheet;  //no worked
    BottomShheetRdrFrgmnt mBottomSheet;

    //7
    Button btnPickupRequest;
    //getting driver nearest8
    boolean isDriverFound = false;
    String driverID = "";
    int radius = 1;//1 km
    int distance =1; // 3km
    private static final int LIMIT = 3;


    //Presense System10
    DatabaseReference driversAvailable;

    //14
    private AutocompleteSupportFragment place_location,place_Destination;
    PlacesClient placesClient;
    List<Place.Field> placeFields = Arrays.asList(Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS);
    String mPlaceLocation, mPlaceDestination;
    //restrict areas15
    //AutocompleteSupportFragment typeFilter; //will be back on this soon
    private AppBarConfiguration mAppBarConfiguration;


    //New Updating Info//26
    CircleImageView imageAvatar;
    TextView txtRiderName, txtStars;
    FirebaseStorage storage; //firestorage for update
    StorageReference storageReference;

    //Vehicle Type
    ImageView carGobalX, carGobalBlack;
    boolean isGobalX=true;

    //MapAnimation:Ripple one
    MapRipple mapRipple ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //fusedLocation
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        //Map
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        //Geo Fire : unuse
       /* ref = FirebaseDatabase.getInstance().getReference(Common.driver_tbl);
        geoFire = new GeoFire(ref); */

        //Init View7
        imgExpandable = (ImageView) findViewById(R.id.imgExpandable);


        //not worke mBottomSheet = BottomSheetRiderFragment.newInstance("Rider Bottom sheet");//by 14;
        mBottomSheet = (BottomShheetRdrFrgmnt) BottomShheetRdrFrgmnt.newInstance("Rider Bottom sheet");
        imgExpandable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBottomSheet.show(getSupportFragmentManager(), mBottomSheet.getTag());
            }
        });



        btnPickupRequest = (Button) findViewById(R.id.btnPickupRequest);
        btnPickupRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Common.isDriverFound )
                    requestPickupHere(FirebaseAuth.getInstance().getCurrentUser().getUid());
                // else
                //Common.sendRequestToDriver(Common.driverId, mServices, getBaseContext(), Common.mLastLocation);
                // sendRequestToDriver(Common.driverId);
                // sendRequestToDriver();

            }
        });
        setUpLocation();

        //places
        Places.initialize(this, getString(R.string.google_places_api_key));
        placesClient = Places.createClient(this);
        place_Destination = (AutocompleteSupportFragment) getSupportFragmentManager()
                .findFragmentById(R.id.place_destination);
        place_location = (AutocompleteSupportFragment) getSupportFragmentManager()
                .findFragmentById(R.id.place_location);
        place_Destination.setPlaceFields(placeFields);
        place_location.setPlaceFields(placeFields);

        place_location.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                mPlaceLocation = place.getAddress().toString();
                //remove old marker
                mMap.clear();
                //add marker at new location
                mUserMarker = mMap.addMarker(new MarkerOptions().position(place.getLatLng())
                        .icon(BitmapDescriptorFactory.defaultMarker())
                        .title("pickup Here !"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 15.0f));


                //Delete toast later
                Toast.makeText(RiderHome.this, ""+place.getName(), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onError(@NonNull Status status) {
                // Toast.makeText(Welcome.this, ""+status.toString(), Toast.LENGTH_SHORT).show();  //delete it too
                Toast.makeText(RiderHome.this, ""+status.getStatusMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        place_Destination.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                mPlaceDestination = place.getAddress().toString();
                //add new destination
                mMap.addMarker(new MarkerOptions().position(place.getLatLng())
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE))
                        .title("Destination"));

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 15.0f));
                //show information in bottom
                //not working
            }

            @Override
            public void onError(@NonNull Status status) {
                Toast.makeText(RiderHome.this, ""+status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        //26Init Storage
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        //adding find view for imgAvaatr ,txtRidername an all;
        View navigationHeaderView = navigationView.getHeaderView(0);

        txtRiderName = navigationHeaderView.findViewById(R.id.txtRiderName);
        txtRiderName.setText(String.format("%s",Common.currentUser.getName()));
        imageAvatar = navigationHeaderView.findViewById(R.id.imageAvatar);

        //loading avatAAR
        if (Common.currentUser.getAvatarUrl() != null && !TextUtils.isEmpty(Common.currentUser.getAvatarUrl())) {
            Picasso.with(this).load(Common.currentUser.getAvatarUrl()).into(imageAvatar);
        }

        //car type
        carGobalX=(ImageView)findViewById(R.id.select_gobal_x);
        carGobalBlack = (ImageView)findViewById(R.id.select_gobal_black);
        //event
        carGobalX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isGobalX = true;
                if(isGobalX)
                {
                    carGobalX.setImageResource(R.drawable.car7);
                    carGobalBlack.setImageResource(R.drawable.bike1);
                }
                else{
                    carGobalX.setImageResource(R.drawable.bike1);
                    carGobalBlack.setImageResource(R.drawable.car7);
                }
                Snackbar.make(mapFragment.getView(),"Gobal -> Car",Snackbar.LENGTH_SHORT).show();
                // Toast.makeText(RiderHome.this, "Gobal -> Car", Toast.LENGTH_SHORT).show();
                mMap.clear();
                if(driversAvailable != null)
                    driversAvailable.removeEventListener(RiderHome.this);
                driversAvailable = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child(isGobalX?"Gobal Car":"Gobal Bike");
                driversAvailable.addValueEventListener(RiderHome.this);
                loadAllAvailableDriver(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()));
            }
        });
        carGobalBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isGobalX = false;
                if(isGobalX)
                {
                    carGobalX.setImageResource(R.drawable.car7);
                    carGobalBlack.setImageResource(R.drawable.bike1);
                }
                else{
                    carGobalX.setImageResource(R.drawable.bike1);
                    carGobalBlack.setImageResource(R.drawable.car7);
                }
                Snackbar.make(mapFragment.getView(),"Gobal -> Bike",Snackbar.LENGTH_SHORT).show();
                mMap.clear();
                if(driversAvailable != null)
                    driversAvailable.removeEventListener(RiderHome.this);
                driversAvailable = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child(isGobalX?"Gobal Car":"Gobal Bike");
                driversAvailable.addValueEventListener(RiderHome.this);
                loadAllAvailableDriver(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()));

            }
        });


    }

    private void requestPickupHere(String uid) {
        DatabaseReference dbRequest = FirebaseDatabase.getInstance().getReference(Common.pickup_request_tbl);
        GeoFire mGeoFire = new GeoFire(dbRequest);
        mGeoFire.setLocation(uid, new GeoLocation(Common.mLastLocation.getLatitude(), Common.mLastLocation.getLongitude()),
                new GeoFire.CompletionListener() {
                    @Override
                    public void onComplete(String key, DatabaseError error) {
                        //here crashing during find driver:Solved
                    }
                });

        if(mUserMarker.isVisible())
            mUserMarker.remove();
        //Add new Marker

        mUserMarker= mMap.addMarker(new MarkerOptions()
                .title("Pickup Here!")
                .snippet("")
                .position(new LatLng(Common.mLastLocation.getLatitude(),Common.mLastLocation.getLongitude()))
                //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE)));
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));  ///For ripple O
        mUserMarker.showInfoWindow();

        //Animation
        mapRipple = new MapRipple(mMap,new LatLng(Common.mLastLocation.getLatitude(),Common.mLastLocation.getLongitude()),this);
        mapRipple.withNumberOfRipples(1);
        mapRipple.withDistance(500);
        mapRipple.withRippleDuration(1000);
        mapRipple.withTransparency(0.5f);

        mapRipple.startRippleMapAnimation();

        btnPickupRequest.setText("Getting driver for you...");
        findDriver();
    }
    private void findDriver() {

        DatabaseReference driverLocation ;
        if(isGobalX)
            driverLocation = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child("Gobal Car");
        else
            driverLocation = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child("Gobal Bike");
        GeoFire gf = new GeoFire(driverLocation);
        final GeoQuery geoQuery =gf.queryAtLocation(new GeoLocation(Common.mLastLocation.getLatitude(),Common.mLastLocation.getLongitude()),radius);

        geoQuery.removeAllListeners();
        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                //if driver mill jaye
                if(!Common.isDriverFound)
                {
                    Common.isDriverFound  = true;
                    Common.driverId = key;
                    btnPickupRequest.setText("Tap a driver to call");
                    Toast.makeText(RiderHome.this, ""+key, Toast.LENGTH_SHORT).show(); //14
                }
            }

            @Override
            public void onKeyExited(String key) {

            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {
                // if still driver not found :)
                if(!Common.isDriverFound && radius < LIMIT) {
                    radius++;
                    findDriver();
                }
                else {
                    if (!Common.isDriverFound) {
                        Toast.makeText(RiderHome.this, "No Driver available near you.", Toast.LENGTH_SHORT).show();
                        btnPickupRequest.setText("REQUEST PICKUP");
                        geoQuery.removeAllListeners();
                    }
                }
            }

            @Override
            public void onGeoQueryError(DatabaseError error) {
            }
        });

    }

    //ctrl o
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case MY_PERMISSION_REQUEST_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    setUpLocation();
                }
        }
    }

    private void setUpLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            //Request runtime Permission
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.CALL_PHONE


            },MY_PERMISSION_REQUEST_CODE);
        }
        else{
            buildLocationCallBack();
            createLocationRequest();
            displayLocation();

        }
    }

    private void buildLocationCallBack() {
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                mLastLocation = locationResult.getLastLocation();
                Common.mLastLocation = locationResult.getLocations().get(locationResult.getLocations().size()-1);//getting last location
                displayLocation();
            }
        };

    }

    private void createLocationRequest() {
        mLocationReqest = new LocationRequest();
        mLocationReqest.setInterval(UPDATE_INTERVAL);
        mLocationReqest.setFastestInterval(FASTEST_INTERVAL);
        mLocationReqest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationReqest.setSmallestDisplacement(DISPLACEMENT);
    }
    private void displayLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                Common.mLastLocation = location;
                if(Common.mLastLocation != null)
                {
                    //Presense System
                    driversAvailable = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child(isGobalX?"Gobal Car":"Gobal Bike");
                    driversAvailable.addValueEventListener(RiderHome.this);

                    final double latitude = Common.mLastLocation.getLatitude();
                    final double longitude = Common.mLastLocation.getLongitude();

                    loadAllAvailableDriver(new LatLng(Common.mLastLocation.getLatitude(),Common.mLastLocation.getLongitude()));
                    Log.d("SAURAABH msg: ",String.format("Your location was change: %f / %f",latitude,longitude));
                }

                else {
                    Log.d("ERROR","Cannot get your location");
                }
            }
        });
    }

    private void loadAllAvailableDriver(final LatLng location) {
       /*
        //first delete all marker on map
        mMap.clear();
        //adding location again
       // mMap.addMarker(new MarkerOptions().position(new LatLng(mLastLocation.getLatitude(),mLastLocation.getLongitude())).title("You"));//by 14
        mMap.addMarker(new MarkerOptions().position(location).title("You"));
*/
        //Add Marker
        // if(mUserMarker != null)  wii cause multiple looops
        // {
        //      mUserMarker.remove(); //Remove Already Marker
        //  }
        mMap.clear();
        mUserMarker = mMap.addMarker(new MarkerOptions()
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                .position(location)
                .title(String.format("You"))
                .snippet(""));

        //Move camera to this Location
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location,15.0f));

        //Load all driver wrt 3km
        DatabaseReference driverLocation ;
        if(isGobalX)
            driverLocation = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child("Gobal Car");
        else
            driverLocation = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child("Gobal Bike");
        GeoFire gf = new GeoFire(driverLocation);

        //GeoQuery geoQuery =gf.queryAtLocation(new GeoLocation(mLastLocation.getLatitude(), mLastLocation.getLongitude()),distance);//14
        GeoQuery geoQuery =gf.queryAtLocation(new GeoLocation(location.latitude,location.longitude),distance);
        geoQuery.removeAllListeners();

        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, final GeoLocation location) {
                //using key to get email from table Users,when driver register & update their info
                FirebaseDatabase.getInstance().getReference(Common.user_driver_tbl).child(key)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                //Bcz Rider & user property is of same,using rider model here to get User
                                Rider rider =dataSnapshot.getValue(Rider.class);

                                if(isGobalX)
                                {
                                    if(rider.getCarType().equals("Gobal Car"))
                                    {
                                        //Adding driver to map
                                        mMap.addMarker(new MarkerOptions()
                                                .position(new LatLng(location.latitude,location.longitude))
                                                .flat(true)
                                                .title(rider.getName()+"\n " + "(tap to call)") //get rider detail
                                                .snippet(rider.getPhone())
                                                //.snippet("Phone : " + rider.getPhone())
                                                //.snippet("Driver ID : " + dataSnapshot.getKey())
                                                // .snippet(dataSnapshot.getKey())
                                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));

                                    }
                                }
                                else{
                                    if(rider.getCarType().equals("Gobal Bike"))
                                    {
                                        //Adding driver to map
                                        mMap.addMarker(new MarkerOptions()
                                                .position(new LatLng(location.latitude,location.longitude))
                                                .flat(true)
                                                .title(rider.getName()+"\n " + "(tap to call)") //get rider detail
                                                .snippet(rider.getPhone())
                                                // .snippet("Phone : " + rider.getPhone())
                                                // .snippet("Driver ID : " + dataSnapshot.getKey())
                                                //.snippet(dataSnapshot.getKey())
                                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));

                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

            }

            @Override
            public void onKeyExited(String key) {

            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {
                if(distance <= LIMIT)// distance just find for 3 km
                {
                    distance ++;
                    loadAllAvailableDriver(location);
                }
            }

            @Override
            public void onGeoQueryError(DatabaseError error) {

            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.rider_home, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.nav_updateInfo){
            showDialogUpdateInfo();
        }
        else if(id == R.id.nav_FAQ){
            FAQ();
        }else if(id == R.id.nav_signOut){
            signOut();
        }
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void FAQ() {
        Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/open?id=1donX83qPJuxAyN6OASb2q1rVSHGRdt6x"));
        startActivity(intent);
    }

    private void showDialogUpdateInfo() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(RiderHome.this);
        alertDialog.setTitle("UPDATE INFORMATION");
        alertDialog.setMessage("Please fill all information");

        LayoutInflater inflater = this.getLayoutInflater();
        View update_info_layout = inflater.inflate(R.layout.layout_rider_update_info, null);

        final MaterialEditText edtName = update_info_layout.findViewById(R.id.edtName);
        final MaterialEditText edtPhone = update_info_layout.findViewById(R.id.edtPhone);
        final ImageView imgAvatar = update_info_layout.findViewById(R.id.imgAvatar);

        alertDialog.setView(update_info_layout);

        imgAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        alertDialog.setView(update_info_layout);

        //setting buttons
        alertDialog.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

                final android.app.AlertDialog waitDialog = new SpotsDialog(RiderHome.this);
                waitDialog.show();

                String name = edtName.getText().toString();
                String phone = edtPhone.getText().toString();

                Map<String, Object> updateInfo = new HashMap<>();
                if (!TextUtils.isEmpty(name))
                    updateInfo.put("name", name);
                if (!TextUtils.isEmpty(phone))
                    updateInfo.put("phone", phone);
                //update
                DatabaseReference RiderInformation = FirebaseDatabase.getInstance().getReference(Common.user_rider_tbl);
                RiderInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .updateChildren(updateInfo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                waitDialog.dismiss();
                                if (task.isSuccessful()){
                                    Toast.makeText(RiderHome.this, "Information update is in processing...", Toast.LENGTH_SHORT).show();
                                Snackbar.make(mapFragment.getView(), "It will take some time :)", Snackbar.LENGTH_SHORT).show();
                            }
                                else
                                    Toast.makeText(RiderHome.this, "Failed update !", Toast.LENGTH_SHORT).show();
                                //waitDialog.dismiss();
                            }
                        });

            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        //show it now
        alertDialog.show();
    }
    private void chooseImage() {
        //start intent to choose img
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Picture: "),Common.PICK_IMAGE_REQUEST);
    }
    //ctrl o
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Common.PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog ProgressDialog = new ProgressDialog(this);
                ProgressDialog.setMessage("Uploading...");
                ProgressDialog.show();

                String imageName = UUID.randomUUID().toString(); //randome name image uploading
                final StorageReference imageFolder = storageReference.child("images/" + imageName);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                ProgressDialog.dismiss();
                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        //upload this url to avatar of user
                                        //first adding avatar property for that ♥
                                        Map<String, Object> Update = new HashMap<>();
                                        Update.put("avatarUrl", uri.toString());

                                        DatabaseReference riderInformation = FirebaseDatabase.getInstance().getReference(Common.user_rider_tbl);
                                        riderInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .updateChildren(Update)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(RiderHome.this, "Updating Avatar... ", Toast.LENGTH_SHORT).show();
                                                            Snackbar.make(mapFragment.getView(),"It will take some time :)",Snackbar.LENGTH_SHORT).show();
                                                        }
                                                        else
                                                            Toast.makeText(RiderHome.this, "Avatar Upload failed !", Toast.LENGTH_SHORT).show();

                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(RiderHome.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                });
                            }

                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        ProgressDialog.setMessage("Uploaded " + progress + "%");
                    }
                });
            }
        }
    }
    private void signOut() {
        AlertDialog.Builder builder;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            builder = new AlertDialog.Builder(this,R.style.Theme_MaterialComponents_Dialog_Alert);
        else
            builder = new AlertDialog.Builder(this);

        builder.setMessage("Do you want to logout ?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        //m here reseting remember value for auto login :B
                        Paper.init(RiderHome.this);
                        Paper.book().destroy();

                        //sign out
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(RiderHome.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.show();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        //map Style18
        try{
            boolean isSuccess = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(this,R.raw.gobal_style_map)
            );
            if (!isSuccess)
                Log.e("Error: ","Map style load failed !!");
        }catch(Resources.NotFoundException ex){
            ex.printStackTrace();
        }


        //pree
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.setInfoWindowAdapter(new CustomInfoWin(this));

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                ////1 check marker
                // destination if not null thn remove available marker
                if(markerDestination != null)
                    markerDestination.remove();
                markerDestination = mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE))
                        .position(latLng).title("Destination"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,15.0f));

                //show bottom sheet

            }
        });
        //call specific driver
        mMap.setOnInfoWindowClickListener(this);

//Updating Locastion"fusedLocation
        if(ActivityCompat.checkSelfPermission(RiderHome.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(RiderHome.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        fusedLocationProviderClient.requestLocationUpdates(mLocationReqest, locationCallback, Looper.myLooper());


    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        //if marker window is rider location, not applying this event
        if(!marker.getTitle().equals("You"))
        {

            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:"+marker.getSnippet()));
            startActivity(intent);

        }
        else
        {
            Toast.makeText(this, "♥", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        loadAllAvailableDriver(new LatLng(Common.mLastLocation.getLatitude(), Common.mLastLocation.getLongitude()));
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }

}
