package com.saurabh.gotrip.Driver;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.github.glomadrian.materialanimatedswitch.MaterialAnimatedSwitch;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.saurabh.gotrip.Driver.Common.Common;
import com.saurabh.gotrip.Driver.Model.GobalDriver;
import com.saurabh.gotrip.R;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;
import dmax.dialog.SpotsDialog;
import io.paperdb.Paper;

public class DriverHome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback

{
    //replacing fusedLocation with letest
    FusedLocationProviderClient fusedLocationProviderClient;
    LocationCallback locationCallback;

    //cp from welcome21
    private GoogleMap mMap;
    //play Services 2
    private static  final int MY_PERMISSION_REQUEST_CODE =7000;
    private static final int PLAY_SERVICES_RES_REQUEST = 7001;
    private LocationRequest mLocationReqest;
    private GoogleApiClient mGoogleApiClient;
    //private Location mLastLocation; // Global now
    private static int UPDATE_INTERVAL = 5000;
    private static int FASTEST_INTERVAL = 3000;
    private static int DISPLACEMENT = 10;
    DatabaseReference drivers;
    GeoFire geoFire;
    Marker mCurrent;
    MaterialAnimatedSwitch location_switch;
    SupportMapFragment mapFragment;
    //Car Animation 3
    private List<LatLng> polyLineList;
    private Marker carMarker;
    private float v;
    private double lat,lng;
    private Handler handler = new Handler();
    private LatLng startPosition,endPosition,currentPosition;
    private int index,next;



    private Button btnGo;//  Replaced by Places API
    private EditText edtPlace;


    private String destination;
    private PolylineOptions polylineOptions,blackPolylineOptions;
    private Polyline blackPolyline,greyPolyline;
    //Search Destination 3

    //Presense System10
    DatabaseReference onlineRef, currentUserRef;
    //PlacesAPI
    PlacesClient placesClient;
    List<Place.Field>placeFields = Arrays.asList(Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS);
    private AutocompleteSupportFragment places;

    //FireBase Storage img uploading23
    FirebaseStorage firebaseStorage;
    StorageReference storageReference;


    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View navigationHeaderView = navigationView.getHeaderView(0);
        TextView textName=(TextView)navigationHeaderView.findViewById(R.id.txtDriverName);
        CircleImageView imageAvatar = (CircleImageView) navigationHeaderView.findViewById(R.id.image_avatar);

        //we have also set in common.current user
        textName.setText(Common.currentGobalDriver.getName());
        //bt with avatar jst chking whether is is null
        if(Common.currentGobalDriver.getAvatarUrl() != null && !TextUtils.isEmpty(Common.currentGobalDriver.getAvatarUrl()))
            Picasso.with(this).load(Common.currentGobalDriver.getAvatarUrl()).into(imageAvatar);





        //cp from welcome21
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        //init view 2
        location_switch = (MaterialAnimatedSwitch)findViewById(R.id.location_switch);
        location_switch.setOnCheckedChangeListener(new MaterialAnimatedSwitch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(boolean isOnline) {
                if(isOnline)
                {
                    FirebaseDatabase.getInstance().goOnline(); //set Online driver when switch on 10

                    //startLocationUpdate();
                    if(ActivityCompat.checkSelfPermission(DriverHome.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                            ActivityCompat.checkSelfPermission(DriverHome.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    {
                        return;
                    }
                    buildLocationCallBack();
                    buildLocationRequest();
                    fusedLocationProviderClient.requestLocationUpdates(mLocationReqest,locationCallback,Looper.myLooper());

                    //Geo Fire
                    drivers = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child(Common.currentGobalDriver.getCarType());
                    geoFire = new GeoFire(drivers);


                    displayLocation();
                    Snackbar.make(mapFragment.getView(),"You are Online",Snackbar.LENGTH_SHORT).show();
                }
                else{

                    FirebaseDatabase.getInstance().goOffline();//disconnected driver when switch offline

                    fusedLocationProviderClient.removeLocationUpdates(locationCallback);


                  //  stopLocationUpdate(); //replaced by fused location
                    mCurrent.remove();//3
                    mMap.clear();//3
                    Snackbar.make(mapFragment.getView(),"You are Offline",Snackbar.LENGTH_SHORT).show();
                }
            }
        });


        setUpLocation();
        //4
        //Places API
        Places.initialize(this,getString(R.string.google_places_api_key));
        placesClient = Places.createClient(this);

        places = (AutocompleteSupportFragment)getSupportFragmentManager()
                .findFragmentById(R.id.place_autocomplete_fragment);
        places.setPlaceFields(placeFields);
        places.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                if(location_switch.isChecked()){
                    destination = place.getAddress().toString();
                    destination = destination.replace(" ","+");
                }
                else{
                    Toast.makeText(DriverHome.this, "Pls change your status ONLINE.", Toast.LENGTH_SHORT).show();
                }
                //Delete toast later
                Toast.makeText(DriverHome.this, ""+place.getName(), Toast.LENGTH_SHORT).show();
            }



            @Override
            public void onError(@NonNull Status status) {
                // Toast.makeText(Welcome.this, ""+status.toString(), Toast.LENGTH_SHORT).show();  //delete it too
                Toast.makeText(DriverHome.this, ""+status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        updateFirebaseToken();

        //23Init FirebaseStorage
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();


    }

    @Override
    protected void onResume() {
        super.onResume();

        //Presense System10
        onlineRef = FirebaseDatabase.getInstance().getReference().child(".info/connected");
        currentUserRef = FirebaseDatabase.getInstance().getReference(Common.driver_tbl)
                .child(Common.currentGobalDriver.getCarType())
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        onlineRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //removing value from driver table when driver disconnected
                currentUserRef.onDisconnect().removeValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onDestroy() {

        FirebaseDatabase.getInstance().goOffline();//disconnected driver when switch offline

        fusedLocationProviderClient.removeLocationUpdates(locationCallback);


        //  stopLocationUpdate(); //replaced by fused location
       // mCurrent.remove();//3
        mMap.clear();//3

        super.onDestroy();
    }

    //cp from welcome
    private void updateFirebaseToken() {
        //update by fused location
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }
    //Press ctrl+o: we request runtime permission, we need override OnRequestPermission Result method
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case MY_PERMISSION_REQUEST_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                   /* if(checkPlayServices())
                    {
                        buildGoogleApiClient();
                        createLocationRequest();

                    */
                   buildLocationRequest();
                   buildLocationRequest();

                        if(location_switch.isChecked()) {
                            //Geo Fire
                            drivers = FirebaseDatabase.getInstance().getReference(Common.driver_tbl).child(Common.currentGobalDriver.getCarType());
                            geoFire = new GeoFire(drivers);
                            displayLocation();
                        }
                    }
        }
    }

    private void displayLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
       // Common.mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient); //fused
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                Common.mLastLocation = location;
                if(Common.mLastLocation != null)
                {
                    if(location_switch.isChecked())
                    {
                        final double latitude = Common.mLastLocation.getLatitude();
                        final double longitude = Common.mLastLocation.getLongitude();

                        //Update to firebase
                        geoFire.setLocation(FirebaseAuth.getInstance().getCurrentUser().getUid(), new GeoLocation(latitude, longitude), new GeoFire.CompletionListener() {
                            @Override
                            public void onComplete(String key, DatabaseError error) {
                                //Add Marker
                                if(mCurrent != null)
                                {
                                    mCurrent.remove(); //Remove Already Marker
                                }
                                mCurrent = mMap.addMarker(new MarkerOptions()
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.car))//remove in 3
                                        .position(new LatLng(latitude,longitude))
                                        .title("You"));
                                //Move camera to this Location
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude,longitude),15.0f));
                                //Draw Animation Rotate Marker: replace by 3 route drawing
                                rotateMarker(mCurrent,-360,mMap);   //if only rotate at starting: remove in 3

                            }
                        });
                    }
                }
                else {
                    Log.d("ERROR","Cannot get your location");
                }
            }
        });
    }
    private void rotateMarker(final Marker mCurrent, final float i , GoogleMap mMap){
        final Handler handler=new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = mCurrent.getRotation();
        final long duration = 1500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float)elapsed/duration);
                float rot = t*i+(1-t)*startRotation;
                mCurrent.setRotation(-rot > 180?rot/2:rot);
                if(t<1.0)
                {
                    handler.postDelayed(this,16);
                }
            }
        });

    }

    private void setUpLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            //Request runtime Permission
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.CALL_PHONE

            }, MY_PERMISSION_REQUEST_CODE);
        }
        else{
            /*if(checkPlayServices())
            {
                buildGoogleApiClient();
                createLocationRequest();  */

            //replacing fusedLocation
            buildLocationRequest();
            buildLocationCallBack();

                if(location_switch.isChecked())
                    displayLocation();
            }
       // }


    }

    private void buildLocationCallBack() {
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                for (Location location:locationResult.getLocations()){
                    Common.mLastLocation = location;
                }
                displayLocation();
            }
        };
    }

    private void buildLocationRequest() {
        mLocationReqest = new LocationRequest();
        mLocationReqest.setInterval(UPDATE_INTERVAL);
        mLocationReqest.setFastestInterval(FASTEST_INTERVAL);
        mLocationReqest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationReqest.setSmallestDisplacement(DISPLACEMENT);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.driver_home, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_container);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.nav_car_type){
            showDialogUpdateCarType();
        }
        else if(id == R.id.nav_sign_out){
            signOut();
         }
        else if(id == R.id.nav_change_pwd){
            showDialogChangePwd();
        }
        else if(id == R.id.nav_update_info){
            showDialogUpdateInfo();
        }

        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showDialogUpdateCarType() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(DriverHome.this);
        alertDialog.setTitle("UPDATE VEHICLE TYPE");
        alertDialog.setMessage("Please fill all information");

        LayoutInflater inflater = this.getLayoutInflater();
        View carType = inflater.inflate(R.layout.layout_update_car_type, null);

        final RadioButton rdi_gobalX = (RadioButton)carType.findViewById(R.id.rdi_gobalX);
        final RadioButton rdi_gobal_black = (RadioButton)carType.findViewById(R.id.rdi_gobal_black);

        //Loading default data from user info

        if (Common.currentGobalDriver.getCarType().equals("Gobal Car"))
            rdi_gobalX.setChecked(true);
        if (Common.currentGobalDriver.getCarType().equals("Gobal Bike"))
            rdi_gobal_black.setChecked(true);



        alertDialog.setView(carType);

        //setting buttons
        alertDialog.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                final android.app.AlertDialog waitDialog = new SpotsDialog(DriverHome.this);
                waitDialog.show();

                Map<String,Object> updateInfo = new HashMap<>();
                if (rdi_gobalX.isChecked())
                    updateInfo.put("carType",rdi_gobalX.getText().toString());
                else if (rdi_gobal_black.isChecked())
                    updateInfo.put("carType",rdi_gobal_black.getText().toString());


                DatabaseReference driverInformation = FirebaseDatabase.getInstance().getReference(Common.user_driver_tbl);
                driverInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .updateChildren(updateInfo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    currentUserRef = FirebaseDatabase.getInstance().getReference(Common.driver_tbl)
                                            .child(Common.currentGobalDriver.getCarType())
                                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid());
                                    Toast.makeText(DriverHome.this, "Vehicle Type Upload !", Toast.LENGTH_SHORT).show();
                                } else
                                    Toast.makeText(DriverHome.this, "Vehicle Type Update Failed !", Toast.LENGTH_SHORT).show();
                                waitDialog.dismiss();
                            }
                        });

                //refreshing Driver data
                driverInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Common.currentGobalDriver = dataSnapshot.getValue(GobalDriver.class);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alertDialog.show();
    }

    private void showDialogUpdateInfo() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(DriverHome.this);
        alertDialog.setTitle("UPDATE INFORMATION");
        alertDialog.setMessage("Please fill all information");

        LayoutInflater inflater = this.getLayoutInflater();
        View layout_pwd = inflater.inflate(R.layout.layout_update_info, null);

        final MaterialEditText edtName = (MaterialEditText)layout_pwd.findViewById(R.id.edtName);
        final MaterialEditText edtPhone = (MaterialEditText)layout_pwd.findViewById(R.id.edtPhone);
        final ImageView image_upload = (ImageView) layout_pwd.findViewById(R.id.image_upload);

        image_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        alertDialog.setView(layout_pwd);

        //setting buttons
        alertDialog.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                final android.app.AlertDialog waitDialog = new SpotsDialog(DriverHome.this);
                waitDialog.show();

                String name = edtName.getText().toString();
                String phone = edtPhone.getText().toString();

                Map<String,Object> updateInfo = new HashMap<>();
                if (!TextUtils.isEmpty(name))
                    updateInfo.put("name",name);
                if (!TextUtils.isEmpty(phone))
                    updateInfo.put("phone",phone);

                DatabaseReference driverInformation = FirebaseDatabase.getInstance().getReference(Common.user_driver_tbl);
                driverInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .updateChildren(updateInfo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(DriverHome.this, "Information update is processing...", Toast.LENGTH_SHORT).show();
                                    Snackbar.make(mapFragment.getView(),"It will take some time :-)",Snackbar.LENGTH_SHORT).show();

                                }
                                else
                                    Toast.makeText(DriverHome.this, "Failed update!!", Toast.LENGTH_SHORT).show();
                                waitDialog.dismiss();
                            }
                        });

            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alertDialog.show();
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Picture: "),Common.PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Common.PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog mDialog = new ProgressDialog(this);
                mDialog.setMessage("Uploading...");
                mDialog.show();

                String imageName = UUID.randomUUID().toString(); //randome name image uploading
                final StorageReference imageFolder = storageReference.child("images/" + imageName);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                mDialog.dismiss();
                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        //upload this url to avatar of user
                                        //first adding avatar property for that ♥
                                        Map<String, Object> avatarUpdate = new HashMap<>();
                                        avatarUpdate.put("avatarUrl", uri.toString());

                                        DatabaseReference driverInformation = FirebaseDatabase.getInstance().getReference(Common.user_driver_tbl);
                                        driverInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .updateChildren(avatarUpdate)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(DriverHome.this, "Avatar verifying...", Toast.LENGTH_SHORT).show();
                                                            Snackbar.make(mapFragment.getView(), "It will take some time :-)", Snackbar.LENGTH_SHORT).show();
                                                        }
                                                        else
                                                            Toast.makeText(DriverHome.this, "Upload failed !!", Toast.LENGTH_SHORT).show();

                                                    }
                                                });
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        mDialog.setMessage("Uploaded " + progress + "%");
                    }
                });
            }
        }
    }

    private void showDialogChangePwd() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(DriverHome.this);
        alertDialog.setTitle("CHANGE PASSWORD");
        alertDialog.setMessage("Please fill all information");

        LayoutInflater inflater = this.getLayoutInflater();
        View layout_pwd = inflater.inflate(R.layout.layout_change_pwd, null);

        final MaterialEditText editPassword = (MaterialEditText)layout_pwd.findViewById(R.id.edtPassword);
        final MaterialEditText editNewPassword = (MaterialEditText)layout_pwd.findViewById(R.id.edtNewPassword);
        final MaterialEditText editRepeatPassword = (MaterialEditText)layout_pwd.findViewById(R.id.edtConfirmNewPassword);

        alertDialog.setView(layout_pwd);
        //setting buttons
        alertDialog.setPositiveButton("CHANGE PASSWORD", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final android.app.AlertDialog waitingDialog = new SpotsDialog(DriverHome.this);
                waitingDialog.show();

                if(editNewPassword.getText().toString().equals(editRepeatPassword.getText().toString()))
                {
                    String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();

                    //get auth credentaials from the user for re-authentication, ex only with email
                    AuthCredential credential = EmailAuthProvider.getCredential(email,editPassword.getText().toString());
                    FirebaseAuth.getInstance().getCurrentUser()
                            .reauthenticate(credential)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()){
                                        FirebaseAuth.getInstance().getCurrentUser()
                                                .updatePassword(editNewPassword.getText().toString())
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful())
                                                        {
                                                            //update Driver ing=fo password column
                                                            Map<String, Object> password = new HashMap<>();
                                                            password.put("password",editRepeatPassword.getText().toString());
                                                            DatabaseReference driverInformation  = FirebaseDatabase.getInstance().getReference(Common.user_driver_tbl);
                                                            driverInformation.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                                    .updateChildren(password)
                                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {
                                                                            if(task.isSuccessful())
                                                                                Toast.makeText(DriverHome.this, "Password Changed successfully.", Toast.LENGTH_SHORT).show();
                                                                            else
                                                                                Toast.makeText(DriverHome.this, "Password changed but not Updated, pls try again.", Toast.LENGTH_SHORT).show();
                                                                            waitingDialog.dismiss();
                                                                        }
                                                                    });
                                                        }
                                                        else {
                                                            Toast.makeText(DriverHome.this, "Password didn't change!", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                    }
                                    else {
                                        waitingDialog.dismiss();
                                        Toast.makeText(DriverHome.this, "Wrong old password !", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
                else {
                    waitingDialog.dismiss();
                    Toast.makeText(DriverHome.this, "Password doesn't match", Toast.LENGTH_SHORT).show();
                }
            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        //show dialof=g finnally saurabh:(
        alertDialog.show();
    }

    private void signOut() {
        AlertDialog.Builder builder;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            builder = new AlertDialog.Builder(this,R.style.Theme_MaterialComponents_Dialog_Alert);
        else
            builder = new AlertDialog.Builder(this);

        builder.setMessage("Do you want to logout ?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        //m here reseting remember value for auto login :B
                        Paper.init(DriverHome.this);
                        Paper.book().destroy();

                        //sign out
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(DriverHome.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.show();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.setTrafficEnabled(false);
        mMap.setIndoorEnabled(false);
        mMap.setBuildingsEnabled(false);
        mMap.getUiSettings().setZoomControlsEnabled(true);

        //Updating Locastion"fusedLocation
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        buildLocationRequest();
        buildLocationCallBack();
        fusedLocationProviderClient.requestLocationUpdates(mLocationReqest, locationCallback, Looper.myLooper());

    }

}
