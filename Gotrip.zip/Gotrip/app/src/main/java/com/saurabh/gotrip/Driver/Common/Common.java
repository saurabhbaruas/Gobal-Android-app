package com.saurabh.gotrip.Driver.Common;

import android.location.Location;

import com.saurabh.gotrip.Driver.Model.GobalDriver;


public class Common {

    //public static String currentToken = "";

    public static final String driver_tbl = "Drivers";
    public static final String user_driver_tbl = "DriversInfo";
    public static final String user_rider_tbl = "RidersInfo";
    public static final String pickup_request_tbl = "PickupRequest";
    public static final String token_tbl = "Tokens";


    public static GobalDriver currentGobalDriver;


    public static final int PICK_IMAGE_REQUEST = 9999; ///pick ipload at23

    public static Location mLastLocation=null;


    public static final String baseURL="https://maps.googleapis.com";
    public static final String fcmURL="https://fcm.googleapis.com/";
    //Auto login systm
    public static final String user_field="user";
    public static final String pwd_field="pwd";


}
